
/* tslint:disable */
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { ColumnDirective, ColumnsDirective, Grid, GridComponent } from '@syncfusion/ej2-react-grids';
import { Group, Inject, Page, PageSettingsModel, Sort, Filter } from '@syncfusion/ej2-react-grids';
import {data} from './datasource';
import './App.css';

export default class App extends React.Component<{}, {}> {
   
    public grid: Grid | null;
    public data: any;
    public pageSettings: PageSettingsModel = { pageSize: 10 };
    
    render() {    
        return (
          <div className='control-pane'>
            <div className='control-section'>
            <GridComponent dataSource={data} ref={g => this.grid = g} pageSettings={this.pageSettings}
                  allowPaging={true} allowGrouping={true} allowFiltering={true} allowSorting={true}>
                <ColumnsDirective>
                  <ColumnDirective field='OrderID' headerText='Order ID' width='120'/>
                  <ColumnDirective field='CustomerID' headerText='Customer Name' width='150'/>
                  <ColumnDirective field='ShipName' headerText='Ship Name' width='120' />
                  <ColumnDirective field='ShipCity' headerText='Ship City' width='150'/>
                </ColumnsDirective>
                <Inject services={[Page, Sort, Group, Filter]} />
              </GridComponent>
            </div>
          </div>)
    }
}
ReactDOM.render(<App />, document.getElementById('grid'));