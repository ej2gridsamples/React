﻿import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import { Link, NavLink } from 'react-router-dom';
import { GridComponent, ColumnDirective, ColumnsDirective, Grid, Group, Inject, Edit, Toolbar, Page } from '../../node_modules/@syncfusion/ej2-react-grids';
import { DataManager, UrlAdaptor, RemoteSaveAdaptor } from '../../node_modules/@syncfusion/ej2-data';
import { Ajax } from '@syncfusion/ej2-base';

interface FetchEmployeeDataState {
    empList: EmployeeData[];
    loading: boolean;
    data: any
}
var ajax;
export class FetchEmployee extends React.Component<RouteComponentProps<{}>, FetchEmployeeDataState> {
    public toolbarOptions: any = ['Add', 'Delete', 'Update', 'Cancel'];
    public editSettings: any = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal' };
    constructor(props) {
        super(props);
    }

    public render() {
        return (<div className='control-section'>
            <GridComponent ref={g => (this as any).grid = g} id="Grid" allowPaging={true} editSettings={this.editSettings} toolbar={this.toolbarOptions} >
                <ColumnsDirective>
                    <ColumnDirective field='OrderID' headerText='Order ID' isPrimaryKey={true} width='120' textAlign='Right'></ColumnDirective>
                    <ColumnDirective field='CustomerID' headerText='CustomerID' width='150'></ColumnDirective>
                    <ColumnDirective field='Freight' headerText='Freight' format="C2" width='120' textAlign='Right' />
                    <ColumnDirective field='EmployeeID' headerText='Employee ID' type='number' editType='numericedit' width='150'></ColumnDirective>
                </ColumnsDirective>
                <Inject services={[Edit, Toolbar, Page]} />a
            </GridComponent>
        </div>)
    }
    componentDidMount() {
        ajax = new Ajax({
            url: "/Home/Datasource",
            type: "POST"
        }).send().then((data: any) => {
            var grid = (document.getElementById("Grid") as any).ej2_instances[0]; // Grid instance
            grid.dataSource = new DataManager({ // provided the dataSource to the Grid through the remoteSaveAdaptor
                json: JSON.parse(data),
                insertUrl: "/Home/Insert",
                updateUrl: "/Home/Update",
                removeUrl: "/Home/Remove",
                adaptor: new RemoteSaveAdaptor()
            });
        })
    }

}

export class EmployeeData {
    employeeId: number = 0;
    name: string = "";
    gender: string = "";
    city: string = "";
    department: string = "";
} 